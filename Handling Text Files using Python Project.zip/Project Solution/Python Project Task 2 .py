#!/usr/bin/env python
# coding: utf-8

# In[45]:


data = open("Desktop/conv.txt", "r").readlines()
unique_chars = set(data)


# In[46]:


word_dict = {}
for line in data:
    words = line.split(":")
    
    if(len(words) >= 2):
        
        name = words[0]
        dirty_spoke = words[1:]
        spoke = ""
        
        for sentences in dirty_spoke:
            spoke = sentences.replace("\n", "")
        
        words = spoke.split()
        
        for word in words:
            words = [words.strip('.,!;()[]') for words in words]
            words = [words.replace("'s", '') for words in words]
            if(name in word_dict):
                word_dict[name].add(word)
            else:
                word_dict[name] = set()
                word_dict[name].add(word)
            


# In[47]:


word_dict.keys()

len(word_dict.keys())

for value in word_dict.items():
    name = value[0]
    unique_words = value[1]
    
    with open(f"{name}.txt", mode = "w") as file_write:
        for words in unique_words:
            file_write.write(words + "\n")


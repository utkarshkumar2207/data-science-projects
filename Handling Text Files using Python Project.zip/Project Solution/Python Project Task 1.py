#!/usr/bin/env python
# coding: utf-8

# In[33]:


data = open("Desktop/conv.txt", "r").read()


# In[35]:


unique_chars = set(data)


# In[37]:


len(unique_chars)


# In[39]:


set(data)

